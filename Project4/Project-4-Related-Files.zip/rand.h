#ifndef __RAND_H__
#define __RAND_H__

int get_cut();
// EFFECTS: returns a random number between 13 and 39

#endif /* __RAND_H__ */
